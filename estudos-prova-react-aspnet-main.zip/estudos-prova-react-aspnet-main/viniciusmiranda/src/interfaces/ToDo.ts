export default interface ToDo {
  id: number;
  title: string;
  description: string;
  status: string;
  categoryId: number;
}
